Applications WaveTool Release Note
===================================

Version 3.3.1 Optical- 11/11/2019
--------------------------------------------
**Issue Fix**
1. v3.2.6 : Math operation Filter is not working for Multislot view (HCPIOP - 994).
2. v3.2.0 : ADXL view gets freezed when Gesture/Angle/LRP view in stop state (HCPIOP - 773).
3. v3.2.0 : In Smoke view log file, operation mode data is not captured on clicking stop in smoke view and giving stop in ADXL view (HCPIOP - 770).
4. v2.0.1: Corrupted ADPD data is observed in MultiSlot View when performing Copy/Paste without clicking Apply in ADPD Config (HCPIOP - 287).
5. v3.1.3: Corrupted ADPD data is observed in Time View when performing Copy/Paste without clicking Apply in ADPD Config (HCPIOP - 696).
6. v2.0.2 : Slots Amplitude range observed as 10^6 range after register dump (HCPIOP - 310).
7. v3.2.6 : BCM View - UI Issues (HCPIOP - 985).
8. v3.2.2 : "No file selected" observed in Loaded DCFG but high level configuration reflecting ADPD4100.dcfg when selecting load dcfg for 2nd time (HCPIOP - 822).
9. v3.2.3 : UI Issue - Previous Loaded DCFG is displayed in ADPD Device (Config) After sensor swapping (HCPIOP - 887).
10. v3.2.0 : SizeGrip Style issues with ADPD view (HCPIOP - 791).
11. v3.2.0 : Proper PPG signal is not updated while changing sampling frequency from 50Hz to any other value and back to 50Hz (HCPIOP - 788).
12. v3.2.0 : ADPD Settings Apply button related issues (HCPIOP - 764).
13. v3.2.0 : "Logging started" message appears in ADXL status bar while playing ADPD view (HCPIOP - 758).
14. v3.2.0 : In ADPD view, No proper alert while setting both slots to OFF state during playback (HCPIOP - 757).
15. v3.2.0 : 'Progress bar' is displayed in ADXL view even after clicking Stop button (HCPIOP - 756).
16. v3.2.0 : Issues with Non - Coolidge ADPD view when it is in stop state (HCPIOP - 713).
17. v3.2.2 : 'Get CTR value' option is in disabled state when Gesture/LRP/Angle view in stop state (HCPIOP - 880).
18. v3.2.2 : In status bar 'UDP progress...' not observed while playing (HCPIOP - 823).
19. v3.2.0 : ADPD Timeview status bar misleads when switching from ADPD config to Time view (HCPIOP - 763).
20. v3.2.0 : Comport connectivity UI issues (HCPIOP - 792).
21. v3.2.0 : In ADXL view "No file selected" message is observed after loading ADXL.dcfg and reopen ADXL config (HCPIOP - 781).
22. v3.2.0 : In PPG view, scaling mislead between graph and X-Axis title when close & reopen the view  (HCPIOP - 769).
23. v3.2.0 : Without enable B to L slots, able to select/de-select CH2, when enable CH2 in SlotA & click apply when cursor placed on any slots except SlotA (HCPIOP - 768).
24. v3.2.0 : In PPG status bar, "Logging started" message is disappeared when stop playback and logging enabled (HCPIOP - 765).
25. v3.3.0 : ADPD device automatically gets closed while invoking other views (HCPIOP - 1022).
26. v3.3.0 : In PPG view, "Reset and connect the watch" alert is observed when click Get Metrics option without "Play" the view (HCPIOP - 1024).
27. v3.3.0 : In PPG view, Sub-sampling check box is in disable state when invoking AWT for first time (HCPIOP - 1025).
28. v3.3.0 : PPG view graph freeze when enabling upto Slot L in ADPD configuration (HCPIOP - 1026).
29. v3.3.0 : In ECG view, "Slot selection" and "ECG Algo type" is in enabled state when the view is in play state (HCPIOP - 1028).
30. v3.3.0 : In ADPD view, Previous ODR observed in log file when changing the ODR continuously in playing state (HCPIOP - 1057).
31. v3.3.0 : Measured ODR update is not unique across ADPD, ECG, PPG views when view is in paused state (HCPIOP - 1063).
32. v3.3.0 : In Sensor Board3 ADPD View, No popup is observed when both slots in OFF state during view playback (HCPIOP - 1066).
33. v3.3.0 : In Sensor Board3 ADPD View, Junk graph data observed after the filter operation done in Math operation (HCPIOP - 1067).
34. v3.3.0 : In Sensor Board3 ADPD view, Expected ODR value not updated as per modified sampling frequency (HCPIOP - 1069).
35. v3.3.0 : In Sensor Board3 ECG view, Electrode type is displayed in enabled state during playback (HCPIOP - 1071).
36. v3.3.0 : In PPG view, Measured ODR's value is observed as half of Expected ODR when Enabling CH2 (HCPIOP - 1072).
37. v3.3.0 : In Sensor board 3 AD5940 View, Data is aligned under Body Temp instead of PCB Temp which misleads user while export to clipboard (HCPIOP - 1075).
38. v3.3.0 : In Sensor board 3 ECG view, "Logging Started..." is observed even logging is after disabled (HCPIOP - 1076).
39. v3.3.0 : "BCM packet loss(0)" appended in log Summarysheet when switching between BCM & anyother views (HCPIOP - 1077).
40. v3.3.0 : In ADPD Time View, graph not updated when selecting 'Second' in X axis Scale option (HCPIOP - 1027).
41. v3.2.6 : In BCM Ref HR (%), '1' is observed when Keying-in '0'  for every 1st time (HCPIOP - 984).


Version 3.3.0 Optical- 09/10/2019
--------------------------------------------
**Issue Fix**
1. v3.1.1 : Measured ODR(Hz) is observed double than the Expected ODR(Hz) when enable CH2 (HCPIOP - 650).
2. v3.2.6 : µV data is not saved in log file for Multislot view (HCPIOP - 1015).
3. v3.2.6: In Multislot view unhandled exception is observed with maximum decimation factor (HCPIOP - 989).
4. v3.2.6 : "Port aleady in use" popup is observed when giving 'Cancel' in "Set Boot Mode" alert & then connect AWT  (HCPIOP - 1000).
5. v3.2.4 : In PPG view, "Get SlotFormat failed" alert is observed when Change the Decimation factor (HCPIOP - 946).
6. v3.2.4 :In PPG view, "Reset and connect the watch" alert is observed when click get CTR option without "Play" the view (HCPIOP - 941).
7. v3.2.6 : In ADPD Multislot view, Math operation selected Source displayed in disabled state when more than 6 slots are enabled with channels 1 & 2 (HCPIOP - 1017).
8. v3.2.6 : "Calibration Failed" is observed for ADPD in Stop state and While ADXL is playback  (HCPIOP - 1016).
9. v3.2.6 : "Calibration Failed" is observed instead of "Stop playback and then try calibration" Notification when ADPD view is in play mode  (HCPIOP - 1010).
10. v3.1.5: Two Log folders created without JSON/m2m2/CSV file while switching between ADPD & ADXL view  (HCPIOP - 708).
11. v3.2.6 : "Stop Playback and then try to load Configuration" alert is observed even ADPD410x view is in stop state  (HCPIOP - 1006).
12. v3.2.6 : In ECG view, Register (1) Read Failed is observed when switching from PLOT_OFF to SLOT_A in slot selection  (HCPIOP - 1005).
13. v3.2.6 : In Multislot view no axis and graph observed with max. decimation value of 128 (HCPIOP - 1004).
14. v3.2.6 : "BCM UnSubscribe Failed" Popup message is observed when Remove the watch from cable on BCM Playback (HCPIOP - 1003).
15. v3.2.6 : In ADXL view, Exception pop-up alert is observed When clicking 'Save Dcfg' on ADXL Config (HCPIOP - 1001).
16. v.3.2.6: In AD5940 view, LoadEDAConfig failed alert is observed when click default DCFG option (HCPIOP - 995).
17. v.3.2.6: In ADPD view, Frequency signal is not updated & Cut-off Freq2 value observed as '0' (HCPIOP - 992).
18. v.3.2.6: In ADXL view,  'Play' icon is in disabled state when disconnect - reconnect during ADXL playback (HCPIOP - 991).
19. v3.2.6 : SB3 ECG View has Optical supported icons when switching from Optical sensor to SB3 (HCPIOP - 987).
20. v3.2.6 : Sensor Board 3 firmware upgrade issues (HCPIOP - 982).
21. v3.2.6: Unhandled Exception observed when enable ECG logging after disconnect the AWT during ECG & ADXL playback with logging enabled state (HCPIOP - 981).
22. v3.2.6: In ADPD Multislot view, Null data observed when switching from samples to seconds for B to L slots (HCPIOP - 979).
23. v3.2.3 : In ADPD multislot view hyperlink not created when enabling and disabling the log multiple times (HCPIOP - 896).
24. v3.2.4: In ADPD view, Signal is not updated when changing the ''TS_CTRL_x' register value from CH2 enable to disable (HCPIOP - 938).
25. v3.2.2 : "Register write failed" is observed when Copy & Paste Slot configuration in ADPD Device (Config) (HCPIOP - 835).
26. v3.2.0 : ADXL view gets freezed when Gesture/Angle/LRP view in stop state (HCPIOP - 773).
27. v2.0.1: Corrupted ADPD data is observed in MultiSlot View when performing Copy/Paste without clicking Apply in ADPD Config  (HCPIOP - 287).
28. v3.1.3: Corrupted ADPD data is observed in Time View when performing Copy/Paste without clicking Apply in ADPD Config  (HCPIOP - 696).
29. v2.1.5 : CH2 is not enabled in HighLevel for writing TS_CTRL_X(0100 to 0260) register values as 4000 via Single Register Control (HCPIOP - 548).
30. v3.2.6 : In SensorBoard3, ADPD Time view has Polynomial in active state for Math operation window (HCPIOP - 1007).
31. v3.2.6 : In ADPD view, Offset parameters are not consistent when adding/removing EEPROM support via config file (HCPIOP - 1013).
32. v3.2.6 : "Incompatible alert" is not observed while opening ADPD When BCM is in Open state (HCPIOP - 998).
33. v3.2.6 : In BCM, after changing X Axis to 'Seconds' still observed X-Axis with previous scale unit (HCPIOP - 997).
34. v.3.2.6: "Stop playing to upgrade FW" alert is displayed when AWT in disconnected state (HCPIOP - 990).
35. PPG signal and Clock Calibration (HCPIOP - 883).
36. v3.2.2 : ADPD Graph freezes on clicking Pause (HCPIOP - 819).
37. v3.2.0 : In log file "19798" value is prefixed in Epoch Delta timestamp when invoking same views after sensor swap (HCPIOP - 778).
38. v3.2.0 : ADPD signal is distorted signal when giving 'Apply' in ADPD Config and immediately clicking  'Stop' button in ADPD Playback when invoking AWT for first time (HCPIOP - 779).
39. v3.2.0 : In ADPD Multislot view, previous data is retained in graph initially when switching from Samples to Seconds in Scale option (HCPIOP - 774).
40. v3.2.0 : In Gesture/Angle/LRP view, "Stop playback/logging and then try to load configuration" Notification displayed while loading dcfg when view playback is in stop state (HCPIOP - 772).
41. v3.2.6 : In SensorBoard3 ADPD view, Software Reset option is not displayed in ADPD config window. But it displayed in ADXL config view (HCPIOP - 1009).
42. v3.2.6 : In AWT main window status bar, "Disconnected" message is observed instead of "Not Connected" when trying to connect the tool with incorrect port (HCPIOP - 999).
43. v3.2.6 : In Multislot view, Math operation GUI is not aligned when shrinking the ODR status (HCPIOP - 983).
44. v3.2.4 : In HR view "Decimation Factor"  is in disabled state when first time invoking (HCPIOP - 940).


Version 3.2.7 Optical- 26/09/2019
--------------------------------------------
**Feature**
1.	Added Experimental ChipDesignView Support
2.	Modified UDP feature to send data based on datapattern.
3.	Modified UDP to send firmware timestamp in header.
4. Added dynamic UI creation in math operation to support adding more than 4 sources.


Version 3.2.6 Optical- 11/09/2019
--------------------------------------------
**Feature**
1.	Dcfg added for Adpd4100
2.	Communication type added for Adpd4100
 
Version 3.2.6 Optical- 03/09/2019
--------------------------------------------
**Feature**
1. As a developer I want to support the context menu options for MS view (HCPIOP - 876).
2. As a developer I want to add the Lit support for Statistics and UDP (HCPIOP - 907).
3. As a developer I want to support the VSM Wavetool features in Applications Wavetool (HCPIOP - 912).
4. As a user I want the q offset base to be same for when I start playing and when I start logging (HCPIOP - 917).
5. Null Offset design is modified "when increasing the number of pulses".
6. Added polynomial suppot in multislot MathOperation.
7. Added VSM PPG and ECG view support in Application Wavetool.
8. Added DeviceInfo details in Json to provide view allow/restrict flexibility.


Version 3.2.4 Optical- 08/08/2019
--------------------------------------------
**Issue Fix**
1. v3.2.3 : In Multislot view, Slot Selection legends still observed in Previous state after loading the ADPD4000.dcfg (HCPIOP-885).
2. v3.2.3 : X axis and Y axis Graph is not observed when disable the Slot A_S1 in multislot view slot selection (HCPIOP-886).
3. v3.2.3 : Multislot view x-axis value is not aligned when drag&move the view (HCPIOP-888).
4. v3.2.3 : In ADPD Multislot view, Graph shows Slot B data when loading ADPD4100 dcfg after softreset (HCPIOP-895).
5. v3.2.3 : Disabled slots are displayed in Multislot graph when enable and disable all slots (HCPIOP - 898).
6. v3.2.3 : In Multislot view, Graph Still Playing After clicking Pause button in ADPD Device (HCPIOP-884).
7. v3.2.3 : In ADPD multislot view hyperlink not created when enabling and disabling the log multiple times (HCPIOP-896).
8. v3.2.3 : ADPD signal playback gets stopped when enable sub-sampling in any one of the slot & disconnect - reconnect after reset (HCPIOP-893).
9. v3.2.2 : ADPD Multislot view graph is not paused when clicking pause after switching from ADXL view and enabling UDP transfer (HCPIOP - 824).
10. v3.2.2 : "No file selected" observed in Loaded DCFG but high level configuration reflecting ADPD4100.dcfg when selecting load dcfg for 2nd time (HCPIOP-822).
11. v3.2.2 : In SNR field, NaN/Wrong value observed when Key-in integer value on Stats offset(R/W) field (HCPIOP-827).
12. v3.2.0 : ADPD graph gets Paused when Click Pause in ADXL graph (HCPIOP - 777).
13. v3.2.2 : Smoke Device ADPD Device Apply button is in enabled state even after loading dcfg (HCPIOP - 857).
14. v3.2.0 : ADPD graph gets updated even when Multislot view is in 'paused' state (HCPIOP-762).
15. v3.2.0 : ADPD view gets freezed while loading the DCFG in the ADXL view (HCPIOP-759).


Version 3.2.3 Optical- 22/07/2019
--------------------------------------------
**Issue Fix**
1. Previous value in sub-sampling is retained when keying in integers greater than '1' in Slot A and '8' in slot C (HCPIOP - 816).
2. Plot2 Expected and Measured ODR is reflected in Plot1 though Plot1 is in OFF state (HCPIOP - 820).
3. Empty JSON folder is created when switching between ADPD and ADXL (HCPIOP - 825).
4. Clock Calibration Failed when enabling any one of the slots from B to L (HCPIOP - 829).
5. "Register (8) Read Failed" is observed when swapping the sensors (HCPIOP - 832).
6. "Register Read(0) failed" is observed when saving dcfg during play mode then loading the same file (HCPIOP - 834).
7. No ADPD graph data observed while enabling SlotA CH2 and calibrate (HCPIOP - 840).
8. AWT Issues on calibrate and reopen ADPD view (HCPIOP - 841).
9. In log file µV data is saved for max ODR instead of particular Slot ODR (HCPIOP - 842).
10. Sub-sampling frequency still in "enabled" state even after user disables the slots (HCPIOP - 817).
11. In Statistics window D1 and D2 is listed when D1 and D2 is in disabled state (HCPIOP - 821).
12. ODR Status improvements in Multislot view (HCPIOP - 828).
13. Operation mode not present in the statistics window while closing and reopen the ADPD view (HCPIOP - 831).
14. Logging Time Format issues (HCPIOP - 844).
15. Smoke Device ADPD Device Apply button is in enabled state even after loading dcfg (HCPIOP - 857).

Version 3.2.2 Optical- 28/06/2019
--------------------------------------------
**Feature**
1. Ch1 and Ch2 data synced while sending via UDP.
2. Statistics support added for multislot.
3. Added hot keys (Ctrl + h) to toggle between Highlevel tab hide/show in ADPD/ADPD4x00 config.

Version 3.2.1 Optical- 20/06/2019
--------------------------------------------
**Feature**
1. Supported ADPD4100 features(HCPIOP - 719).
2. Supported interrupt status in the ADPD Device window (HCPIOP - 720).
3. Added lead status in ECG view.
4. Added X2 axis in overlap graph selection for ADPD coolidge timeview
5. Added UDP commands for open view,channel select,tab select, load cloud config.

Version 3.2.0 Optical- 22/05/2019
--------------------------------------------
**Issue Fix**
1. Two Log folders created without JSON/m2m2/CSV file while switching between ADPD & ADXL view (HCPIOP - 708).
2. PPG View Log data not saved for entire duration in long run (HCPIOP - 709).
3. Able to change the sample count while ADPD is in playback state (HCPIOP - 656).
4. Applied value is not displayed for sampling frequency in highlevel after changing in Register level (HCPIOP - 549).

Version 3.1.6 Optical- 23/05/2019
--------------------------------------------
**Issue Fix**
1. Added support for ADPD4100.

Version 3.1.5 Optical- 10/05/2019
--------------------------------------------
**Issue Fix**
1. ADXL timestamp is always updated with addition of 20min with current timestamp (HCPIOP - 544)
2. Statistics datas are not updated in Timeview statistics window when clicking Update or Run (HCPIOP - 653)
3. Disconnect button is changed to connect when clicking Cancel for Logging is in Progress alert (HCPIOP - 658)
4. ADXL Graph is not updating when playing the ADXL Device 2nd time with ADPD Device running along with Statistics window open state (HCPIOP 661)
5. "Click to open" hyperlink is displayed even when logging is in enabled state in ADXL Device (hcpiop - 662)
6. ADXL data is not updating and log is not saved after giving cancel to the Sensor Swap instruction alert message (HCPIOP - 691)
7. Raw Data not saved in logs after giving cancel to the Sensor Swap instruction alert message (HCPIOP - 694)
8. Part of Slot B data is observed in end of Slot A log (HCPIOP - 693)
9. PPG View is always in Opened state eventhough swapped to Non Coolidge sensor (HCPIOP - 692)
10. Graph line width is automatically changed into "Thin" when disable any one of the slot when graph mode is an "Operation" (HCPIOP - 551)
11. Continuous Update is in disabled state after stop/play the view with update once in statisics window (HCPIOP - 546)
12. Slidebar observed in main window unexpectedly after dragging the angle icon (HCPIOP - 541)
13. Math operation Source option drop down menu is not refreshed when user mistakenly removes cable & reconnects (HCPIOP - 523)
14. Non-Coolidge information is observed in Coolidge Stats data when playing with single slot in Time View (HCPIOP - 518)
15. "No MCU motherboard Found" observed while disconnect & reconnecting the WT after ADPD playback with 400Hz ODR (HCPIOP - 315)
16. Q-Offset data is not observed in MultiSlot View graph when enabling the Slot B to L after Q-Offset is enabled (HCPIOP - 293)
17. In ADPD device, Signal not observed when Load any unsupported dcfg to coolidge.dcfg (HCPIOP - 173)
18. ADPD playback gets corrupted when enable/disable the 'Log' option continuously while long hours log file conversion is in progress (HCPIOP - 171)
19. Applications WT goes to Not responding state while clicking on "Export to clipboard" when Samples value(X-axis) is more than 100000 (HCPIOP - 154)
20. "ADXL Unsubscribe failed" observed while close the AWT main window during Angle view playback state (HCPIOP - 660)
21. In PPG view,"value cannot be null.parameter name:path" notification observed while clicking on "click to open log" for first time(HCPIOP-651)
22. Measured ODR(Hz) is observed double than the Expected ODR(Hz) when enable CH2(HCPIOP-650)
23. Applied value is not displayed for sampling frequency in highlevel after changing in Register level(HCPIOP-549)
24. Settings Window not disappeared while unplug the UART cable(HCPIOP-547)
25. In ADPD view SlotB graph X axis samples are updated even when slotB is disabled in control group box(HCPIOP-516)
26. UDP Transfer state status is not found in ADPD Device Multislot View(HCPIOP-697)
27. 'Success' response observed for invalid commands in UDP Controller(HCPIOP-700)

Version 3.1.4 Optical- 06/05/2019
--------------------------------------------
**Feature**
1. As a user I want the GUI changes to support ADXL view for Coolidge (HCPIOP - 663)
2. As a user I want an option to disable the M2M2 raw data in UDP packets using config (HCPIOP - 664)
3. As a user I want to send ADXL data through UDP  (HCPIOP - 665)


Version 3.1.3 Optical- 24/04/2019
--------------------------------------------
**Feature**
1. The timestamps do not match the current time when mathematically converted (HCPIOP - 605).
2. As a user I want the Wavetool to enable automatically switch sensor boards with a button from Wavetool (HCPIOP - 607).
3. As a developer I want to refractor the packet structure for sending UDP raw data to include the configuration also (for ADPD 108 or Coolidge slots configured) (HCPIOP - 593).
4. As an apps engineer I want the PPG view to allow configuration for LCFG from a file (HCPIOP - 595).
5. As a user I want PPG view for ADPD Coolidge to be supported (HCPIOP - 596).
6. As a user I want UDP transfer supported for multislot view (HCPIOP - 599).

Version 3.1.2 Optical- 16/04/2019
--------------------------------------------
**Issue Fix**
1. Firmware updated - version 3.6.0

Version 3.1.1 Optical- 29/03/2019
--------------------------------------------
**Feature**
1. As a user I want the raw data packets to be passed with UDP along with plot selected data (HCPIOP - 586).
2. As an apps engineer I want the UDP capabilities to be enhanced (HCPIOP - 553).
3. As a developer I want the PPG view in Wavetool similar to VSM Wavetool  (HCPIOP - 526).
4. As an apps engineer I want the Statistics for multislot view and logging capabilities for Math operations (HCPIOP - 487).


Version 3.1.0 Optical- 28/03/2019
--------------------------------------------
**Feature**
1. Added support for software reset in ADPDCL configuration.


Version 3.0.1 Optical- 20/03/2019
--------------------------------------------
**Issue Fix**
1. Samples skip issue in CSV log file in ADPDCL.


Version 3.0.0 Optical- 07/03/2019
--------------------------------------------
**Issue Fix**
1. v2.0.1 : No Source option is displayed as twice in Math Operation window when both Slots are in OFF state (HCPIOP - 294).
2. v2.1.4 : Unit Option gets enabled when enable & disable the log while Null offset enabled state.
3. v2.1.4: Invalid Sample count alert is not displayed when playing the view with Samples count less than ODR.
4. v2.1.3: Issues in Stats Offset(R/W) field at Statistics window (HCPIOP-519).


Version 2.1.6 Optical- 06/03/2019
--------------------------------------------
**Issue Fix**
1. v2.1.3: Unhandled Exception when pressing 'm' in Power Calculation UI of Non-Coolidge ADPD Config (HCPIOP-513).
2. v2.1.3 : In ADPD view SlotB graph X axis samples are updated even when slotB is disabled in control group box (HCPIOP-516).
3. v2.1.5 : "Get Firmware version failed" alert is displayed after FW update.
4. v2.1.3: UI mislead in Non-Coolidge & Coolidge views. (Fixed Impact) (HCPIOP-521).
5. v2.1.4 : While close the WT during disconnected state, it takes 5 to 6 seconds.
6. v2.1.5 : Empty EEPROM name in main window for ADPD105Z- GEST & PROX sensor instead of any appropriate name.
7. v2.1.4 : In Smoke view, Nulloffset is in enabled state when logging is in progress.
8. v2.1.5 : In Non-Coolidge sensor, Signal not observed in all views after loaded the dcfg in Angle, ADPD, Gesture, LRP view.
9.  v2.1.4: ADPD/Smoke view data gets stopped when toggle the log option in ADXL view.
10. v2.1.4 : Latest ver of tool is not displayed when clicking on "Check for Update" option.


Version 2.1.5 Optical- 27/02/2019
--------------------------------------------
**Issue Fix**
1. Slot mode not updated issue fixed.
2. Slot enable enables only CH1 checkbox (checked) and disables CH2 checkbox. This checkbox control is enabled only when Apply is Hit.This checkbox should be enabled but unchecked when Slot is enabled
3. Slot disable should disable all the controls in the tab page
4. AFE Fine Offset is renamed as Integ Offset
5. Even if I load a config, the slot is bypassed by default. When a config is loaded all the slots configured should be enabled.
6. When I load ADPD4000_ECG.dcfg and then load ADPD4000_std_floatmode_ECG.dcfg, the Slot mode is still Float_Amb.Then if I load ADPD4000_default, there is no Slot mode displayed.


Version 2.1.4 Optical- 15/02/2019
--------------------------------------------
**Feature**
1. As a user I want the Smoke view controls to be rearranged to make it more user friendly (HCPIOP-420).
2. As a developer I want to update the tooltips for all the controls in the AWT JSON files (HCPIOP-481).
3. As a developer I want the firmware updated features to be corrected to boot from Wavetool (HCPIOP-490).
4. As an apps engineer I want the private registers to not be listed in the Register Tab of ADPD CL Config (HCPIOP-482).


Version 2.1.3 Optical- 11/02/2019
--------------------------------------------
**Feature**
1. As a user I want automatic update of the software to be added when a new version is available in the AWS server (HCPIOP-375).
2. As a user I want the ADPDCL config controls to be rearranged to make the look more friendly and easy to use (HCPIOP-415).
3. As a user I want the ADPD config controls to be rearranged to make the look more friendly and easy to use (HCPIOP-416).
4. As a user I want the Main Window controls to be rearranged to make it more user friendly (HCPIOP-417).
5. As a user I want the Statistics window controls to be rearranged to make it more user friendly (HCPIOP-419).

**Issue Fix**
1. v2.1.0 : In Statistics window Mean value is not updated when entering the offset value for second time (HCPIOP-363).
2. v2.0.1: Invalid Sample count alert is not displayed when playing the view with Samples count less than ODR (HCPIOP-280).
3. v2.0.0 : CH2 is not Enabled/Disabled in High Level when writing TS_CTRL(0100 to 0260) register values from Register View/Single Register Control (HCPIOP-163).


Version 2.1.2 Optical- 22/01/2019
--------------------------------------------
**Feature**
1. As an apps engineer, I want the Remote DCFGs to have internal field and to be made available if the INTERNAL config field is enabled in the config file (HCPIOP-371).
2. As an apps engineer I want the ADPD View to be cleaned and controls rearranged to make it smaller and neat (HCPIOP-372).
3. As a developer I want the framework for adding tooltips in a JSON file for each control to be added so that the relevant tooltip can be added by the apps engineer (HCPIOP-373).
4. As a user I want the documentation to be downloaded from the AWS site during startup of the tool (HCPIOP-374).
5. Reduce the time it takes to open views and the ADPD Config window (HCPIOP-351).
6. As an apps engineer, I want the timing control to be updated with additional register settings for Float LED and Float Ambient modes (HCPIOP-35).

**Issue Fix**
1. v2.0.1 : "Reset and Connect the watch" alert is observed when switching from Debug info to ADPD Calibration select (HCPIOP-296).
2. v2.0.4: Unhandled Exception when entering dot(.) in Offsets field of Statistics UI (HCPIOP-347).
3. v2.0.4 : With Q-Offset, Unit option is in enabled state When switching between Overlap & No Overlap (HCPIOP-348).
4. v2.0.4 : Unable to enable & disable the BPF option when ADPD/Smoke View is in "play" state (HCPIOP-349).
5. v2.1.0 : Log file is not saved when switching between Enable & disable "log" option in Multiple views (HCPIOP-358).


Version 2.1.1 Optical- 20/12/2018
--------------------------------------------
**Feature**
1. As a apps engineer I want a provision to host the configuration files in a cloud drive to be updated on the fly (HCPIOP-105).
2. As a user I want the filter operation to be updated to choose any filter from the JSON list in Math operation in ADPD and ADPD Coolidge (HCPIOP - 322).
3. As a applications engineer I would like to control the Impulse mode so that I can configure slot and control additional registers (HCPIOP - 31).
4. As an apps engineer I want the Impulse mode packets to be logged for future analysis (HCPIOP - 33).
5. As an apps engineer I want the configuration examples to use the new naming convention (new DCFGs) to maintain consistency with the Optical team (HCPIOP - 43).


Version 2.1.0 Optical- 30/11/2018
--------------------------------------------
**Issues**
1. v2.0.4 : Unit Option is enabled in Operation graph when enable & disable the log option (HCPIOP - 319).
2. v2.0.4 : CSV Log file is not updated properly while enable Q-Offset & Tap Count other than 8. (HCPIOP - 321).

**Modification**
1. Included UDP Tools in etc folder and corresponding document in doc folder.
2. Added STM driver in etc folder. 

Version 2.0.4 Optical- 29/11/2018
--------------------------------------------
**Issues**
1. v2.0.1 : In ADPD Time view, Corrupted signal is observed with CH2 enabled & Low power enable/disable in any slot [B to L] with A Slot(HCPIOP - 297).
2. v2.0.3 : UDP options goes to inactive state after disconnect the WT when UDP transfer is in enabled state(HCPIOP - 313).
3. v2.0.2 : Selected Unit data is not captured in log file when Stop & Play the ADPD/Smoke view(HCPIOP - 309).
4. v2.0.1 : In ADXL Device, Frequency view Y axis is disable state for Non-coolidge sensor(HCPIOP - 283). 
5. Fixed firmware upgrade window struck without any progress.

Version 2.0.3 Optical- 27/11/2018
--------------------------------------------
**Feature**
1. As an apps engineer, I want the Dfuse libraries to be included in the package to enable easy upgrade of the M4 firmware. (HCPIOP-278).
2. In coolidge, When copying slot configurations, some register are not marked for DCFG updates (HCPIOP-217).
3. As an apps engineer I want additional filter operations to be added in the ECG view to offset the signal and remove noise. (HCPIOP-298).
4. As an apps engineer I want the log file for ECG to log uV and filtered data along with raw data to perform further analysis. (HCPIOP - 299).
5. As an apps engineer I want a GUI option to set the capacitance value for ECG view and uV calculation (HCPIOP - 300).
6. As a developer I want to test the ECG and smoke view to fix issues and bugs and make it ready for release (HCPIOP - 301).
7. As a user I want the UDP options to be enabled if UDP transfer is not happening (HCPIOP - 302).

**Issue Fix**
1. v2.0.2: Progress bar is displayed even after collecting data is completed in Frequency View. (HCPIOP - 303).
2. v2.0.2: Incompatible view alert is displayed after current view is closed when responding to FW update alert message.(HCPIOP - 304).
3. v2.0.2 : When enable & disable the Q-offset, None of the Unit is selected in Unit option. (HCPIOP - 305).
4. v2.0.2 : Unit option is enabled in Operation graph when enable & disable the Q-offset. (HCPIOP - 306).
5. v2.0.2 : In Statistics window Offset value is added twice with the Previous Mean value. (HCPIOP - 307).
6. v2.0.2 : Operation graph related issues. (HCPIOP - 308).
7. v2.0.1: ADPD Raw data is not saved in log file when set Unit as CTR/PTR for any one of the slot. (HCPIOP - 279).

Version 2.0.2 Optical- 20/11/2018
--------------------------------------------
**Feature**
1. As a customer I want ECG View to be added to the Applications Wavetool to analyze the ADPD data as ECG signal (HCPIOP-156).
2. As a developer I want to create a Template View Baseclass using which all the other views can be derived to avoid duplication of code (HCPIOP-157).
3. As a customer I want the ECG algorithm to be embedded in the ECG view to give meaningful results of the sensor data (HCPIOP-228). 
4. As an apps engineer I want the CTR/PTR data to be passed through UDP sockets to perform further analysis in another computing tool (HCPIOP-229).
5. As an apps engineer I want statistics and operation to be calculated using CTR/PTR units when CTR/PTR is enabled (HCPIOP-143).
6. As a developer I would like to update the firmware with the latest release version and update the necessary sections in Wavetool (HCPIOP-242).
7. As an apps engineer I want the uV unit calculation to be corrected for the user change in capacitor size(HCPIOP-245).
  
**Issue fix**
1. v2.0.0 : Data is not updating when switching between ADXL and/or other views(HCPIOP-158).

Version 2.0.1 Optical- 29/10/2018
--------------------------------------------
**Feature**
1. As an apps engineer I want Filter option in Math Operation to perform filtering of the data before analyzing the waveform (HCPIOP-155).
2. As an apps engineer I want appropriate Bandpass Filter constants as a function of gain and pulsewidth to correct the CTR measurements (HCPIOP-183).
3. As an apps engineer I want the data presented in the smoke view in PTR units to validate the data (HCPIOP-61). 
4. As an apps engineer I want to log the CTR data along with raw data when CTR units are selected (HCPIOP-139).
5. As an apps engineer I want option to change the timescale from samples to seconds to analyze data for ECG (HCPIOP-179).
6. As an apps engineer I want new scale multiplier and units for ADPD view to analyze the data for ECG mode (HCPIOP-178).
  
**Issue fix**
1. reading 16bit address (0x100 and above) cannot be read with UDP and fails (HCPIOP-168).
2. v2.0.0 : Log file is not saved in Logs folder for ADPD view. (Non-Coolidge) (HCPIOP-146).
3. In smoke view the ratio graph is showing slotA/slotB even when I interchange the slots (HCPIOP-144). 


Version 2.0.0 Optical- 12/10/2018
--------------------------------------------
**Feature**
1. Unit conversion, scale and freeze scale option is added in zedgraph context menu.
2. 1.8.7 and 1.9.2 merged into a single software
3. Graph title is changed based on LED selection in smoke view operation mode.
4. CTR option added in smoke view.
5. The data to be played back from a file option to be used for testing and validation (HCPIOP-62 ).
6. The data samples to log the Q-offset data instead of raw data when Q-offset is enabled (HCPIOP-106). 
7. The exceptions in Main Program to be logged in a Log File to be used for analysis later (HCPIOP-34).
8. Add ADXL data to the logged data file for the ADPD view (HCPIOP-99 ).
9. Graph labels to reflect the math operation being performed (HCPIOP-107 ).
10. The graph lines for slot A and B to have a different line color than the LED color, in Smoke view (HCPIOP-108). 

**Issue fix**
1. v2.0.0.1 - Optical : ADPD packet loss is observed while enable logging 2nd time during playback state(Sanity-Issue ID :2).
2. v2.0.0.1 - Optical : In Multislot view, incorrect y-axis graph is observed while enable Q offset then close/disconnect & reopen the view(Sanity-Issue ID :3).
3. v2.0.0.1 - Optical : Issues in Log option with Non-coolidge ADPD device(Sanity-Issue ID :4).
4. v2.0.0.1 - Optical : Improvement Release Notes(Sanity-Issue ID :5).
5. v2.0.0.1 - Optical : ADXL graph freezes with FFT Size other than default value(1024)(Sanity-Issue ID :6).
6. v2.0.0.1 - Optical : Channels groupbox in Smoke Device mislead after switching from ADPD Device(Sanity-Issue ID :7).
7. v2.0.0.1 - Optical : Slot mode variation between ADPD config, Channels group box & Graph view after changing slot 4ch16/4ch32 from slot off state(Sanity-Issue ID :8).
8. v2.0.0.1 - Optical : Improvement - In smoke device_Frequency view, Peak value label in graph should be displayed(Sanity-Issue ID :9).
9. v2.0.0.1 - Optical : ADPD data not observed with Samples value = 10 Million in Multislot view(Sanity-Issue ID :10).
10. v2.0.0.1 - Optical : Update statistics & Continuous update options are in enabled state when reopen the statistics window(Sanity-Issue ID :11).
11. v2.0.0.1 - Optical : Improvement - Healthcare icon is displayed in Connect window(Sanity-Issue ID :12).
12. v2.0.0.1 - Optical :� Smoke view Cal select options are reflected in all other views(Sanity-Issue ID :14).
13. v2.0.0.1 - Optical : ADPD data gets stopped when writing OPMODE(0010) register via UDP Controller tool(Sanity-Issue ID :15).
14. v2.0.0.1-  Optical: Slot related issues in Coolidge(Smoke ID :1(found by Dalton)).
15. v2.0.0.1 - Optical : 'Restore' functionality is not working for Internal avg when the value is empty(Smoke-Issue ID :3).
16. v2.0.0.1 - Optical : Statistics Window related issues(Smoke-Issue ID :4).
17. v2.0.0.1 - Optical : Issues in ADXL config window(Smoke-Issue ID :5).
18. v2.0.0.1 - Optical : ADPD Signal not observed after "Low power" option enabled & disabled for any slots during playback state(Smoke-Issue ID :6).
19. v2.0.0.1 - Optical : While Uninstalling the Application_WT, "CoolidgeRegDef.xml" file is not removed in "etc" folder(Smoke-Issue ID :7).
20. v2.0.0.1 - Optical : Cut-Off Freq2 unit is not displayed fully in Frequency view of ADPD Device(Smoke-Issue ID :9).
21. v2.0.0.1 - Reading 16bit address (0x100 and above) can't be read with UDP and fails (HCPIOP-168).


Version 2.0.0.1 Optical- 12/09/2018
--------------------------------------------
**Modification**
1. 1.8.7 and 1.9.2 merged into a single software

Version 1.8.7-QA4 Optical- 27/08/2018
--------------------------------------------
**Issue fix**
1. #927: v1.8.7 - QA2-Optical : In Angle View, Data is not updated in graph when any one of the slot disabled & Zero Offsets is Enabled
2. #929: v1.8.7 - QA3-Optical : In Smoke Device, Frequency view -> Scaling option is not reflected in FFT graph
3. #933: v1.8.7 - QA3 Optical: Uninstall process is happened when clicking on uninst.exe during Applications Wavetool is in open state

Version 1.8.7-QA3 Optical- 22/08/2018
--------------------------------------------
**Improvements**
1. Dcfg files segregation in the Load config is removed
2. Sample Count limit is extended in the time view graph

**Issue fix**
1. #902: v1.8.7 - QA1 Optical : Tool shows connected state after FW update even without connection
2. #917: v1.8.7 - QA2 Optical : Issues on FW update when switching from M4 to M3
3. #919: v1.8.7 - QA2 Optical : GUI Issues @ 125% Resolutions
4. #920: v1.8.7 - QA2 Optical : In ADPD view, ADPD config -> Slot Format option is invisible state when switching from LRP view
5. #921: v1.8.7 - QA2 Optical : In ADPD view Math Operation 4th source value is not updated in operation graph

Version 1.8.7-QA2 Optical- 14/08/2018
--------------------------------------------
**Feature**
1. AutoScale functionality is added in ADPD view
2. Rearranging the ADPD Config Window and UI imrprovements

**Issue fix**
1. #902: v1.8.7 - QA1 Optical : Tool shows connected state after FW update even without connection
2. #903: v1.8.7 - QA1 Optical : Bitmap View is not getting refreshed
3. #909: v1.8.7 - QA1 Optical : Graph is not updating when clicking Mode calibration after calibrating with Cal.Select Option
4. #910: v1.8.7 - QA1 Optical : Incompatible view alert is displayed even after Remove cable and Reconnect the board
5. #913: v1.8.7 - QA1 Optical : Unhandled exception is observed when Playing the ADXL view
6. #914: v1.8.7 - QA1 Optical : Default configurations are not loaded when clicking Default DCFG button in ADXL Config
7. HCPIOP-24: v1.8.7 QA1 - Popup warning for firmware mismatch

Version 1.8.7-QA1 Optical- 03/08/2018
--------------------------------------------
**Feature**
1. Efuse EEPROM Register Read has been added.
2. Logging feature is added in Smoke view.
3. Slot selection section is modified in ADPD & Smoke view.

**Issue fix**
1. #658: Reset is required after the firmware update failed
2. #829: v1.8.5.3 Optical: Register write command in UDP Controller is not working properly.
3. #837: v1.8.5.3-Optical: Issues when loading DCFG files via WT and UDP.
4. #838: v1.8.5.3 Optical: Unhandled Exception when pasting special characters in Distance(mm) field of Angle View
5. #870: v1.8.6.1-Optical: Can't able to open ADPD view via UDP when ADXL view is already opened
6. #871: v1.8.6.1-Optical: Unhandled Exception is observed when Enable & Disable the "Q Offset" option in ADPD Device
7. #891: v1.9.9 : Unhandled Exception is observed when writing the Pulse_Period Register via Bit Map view.
8. #839: 1.8.5.3 Optical: "Register Dump Info" window is observed with whitespace when resize
9.#815: v1.8.5.1 Optical: Unable to Load DCFG in ADPD config with any View is in stop state and ADXL view is in play state

Version 1.9.2 QA1 Coolidge - 03/08/2018
--------------------------------------------
**Feature**
1. IMPULSE MODE,Digital Integrate,TIA_ADC - Unbuffered,TIA_ADC - Buffered,Float LED Mode,Normal mode,Float Ambient Mode,Pulse Connect Mode are displayed in highlevel view based on corresponding register change. 

--------------------------------------------
Version 1.9.1 TB5 Coolidge - 26/07/2018
--------------------------------------------
**Issue fix**
1. Registers write and UI update when loading dcfg file. 
2. BitMap Field update when changing a particular bitvalue.
3. Some of the slot data is missing in multislot view(#974).
4. Improvements in UI update and timing Issue fix.
5. Channel control checkbox is changed to user control from register control in ADPDCL Timeview.

--------------------------------------------
Version 1.9.1 Preview Coolidge - 18/07/2018
--------------------------------------------
**Feature**
1. Multi slot Graph View.
2. Separate Log file for Time view & Multislot view.
3. Log Configurations.
4. In Time view,Math Operation feature is added in ADPDCL( For D1,S1,D2,S2 data) for corresponding slots selected(Plot1 & Plot2).
5. Combined CSV file of individual log files for different slots.
6. Q offset enabled in multi slot view.
**Issue fix**
1. In ADPDCL, data streaming not started in Multislot view(#893).
2. QA issue fixes done.

Version 1.9.0a Coolidge - 12/06/2018
--------------------------------------------
**Feature**
1. LED disable register(PATTERN_X) write issue is fixed.

Version 1.9.0 Coolidge - 05/06/2018
--------------------------------------------
**Feature**
1. Graph View
2. Statistics Window
3. Highlevel View
4. Clock Calibration Window
5. Power Calculation Window
6. Register Dump

