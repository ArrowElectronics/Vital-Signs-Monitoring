﻿using Analog.Register;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CSharp
{
    class ScriptClass
    {
        #region REFORMAT_SAVED_DCFG        
        private Dictionary<uint, uint> dict_Ref_saveDcfg = new Dictionary<uint, uint>();
        private Dictionary<uint, RegisterInfo> dict_RegisterInfo_All = new Dictionary<uint, RegisterInfo>();
        private SortedDictionary<uint, RegisterInfo> sorted_dict_RegisterInfo_All = new SortedDictionary<uint, RegisterInfo>();
        private Dictionary<string, SortedDictionary<uint, RegisterInfo>> dict_RegisterInfo_categorized = new Dictionary<string, SortedDictionary<uint, RegisterInfo>>();
        private SortedDictionary<string, SortedDictionary<uint, RegisterInfo>> dict_TimeSlotX_categorized = new SortedDictionary<string, SortedDictionary<uint, RegisterInfo>>();
        private List<string> lst_TimeSlotX_category;
        private RegisterClass m_rc = RegisterClass.ADPDRegInstance;
        private const string XML_EMPTY_STRING = "\"\"";

        public void RunScript(string dcfg_Path)
        {
            try
            {
                m_rc = RegisterClass.ADPDRegInstance;
                //Init
                InitScript();

                //Parse saved Dcfg
                var parse_status = Parse_SavedDCFG(dcfg_Path);

                if (parse_status)
                {
                    //Populate RegisterInfo List
                    PopulateRegisterInfoList();

                    //Categorize the Register Definition
                    var status = Categorize_RegisterInfo(dcfg_Path);

                    if (!status)
                    {
                        MessageBox.Show("Formating Saved Dcfg Failed");
                    }

                    CreateDcfgHeaderFile(dcfg_Path);

                    //Clear the dictionary            
                    dict_RegisterInfo_All.Clear();
                    sorted_dict_RegisterInfo_All.Clear();
                    dict_RegisterInfo_categorized.Clear();
                    dict_TimeSlotX_categorized.Clear();
                }

                Cursor.Current = Cursors.Default;
                Console.WriteLine("Conversion Completed");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in Runscript API = " + ex);
            }
        }

        private void InitScript()
        {
            try
            {
                //Timeslot Configuration categories
                lst_TimeSlotX_category = new List<string>();

                //ADPD4x00
                lst_TimeSlotX_category.Add("TimeSlot Configuration");
                lst_TimeSlotX_category.Add("AFE Timing Setup");
                lst_TimeSlotX_category.Add("LED Control and Timing");
                lst_TimeSlotX_category.Add("ADC Offset");
                lst_TimeSlotX_category.Add("Threshold Setup and Control");

                //ADPD10x
                lst_TimeSlotX_category.Add("LED Control");
                lst_TimeSlotX_category.Add("ADC Register");
                lst_TimeSlotX_category.Add("Pulse Control");
                lst_TimeSlotX_category.Add("AFE Configuration");
                lst_TimeSlotX_category.Add("AFE Control");
                lst_TimeSlotX_category.Add("AFE channel compensation");
                lst_TimeSlotX_category.Add("Analog Offset Control");
                lst_TimeSlotX_category.Add("QReset");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in InitScript API = " + ex);
            }
        }

        private bool Parse_SavedDCFG(string savedDcfg)
        {
            bool status = false;

            try
            {
                if (savedDcfg != string.Empty)
                {
                    var extension = Path.GetExtension(savedDcfg);
                    if (extension.ToLower() == ".dcfg")
                    {
                        if (!File.Exists(savedDcfg))
                        {
                            Console.WriteLine("saved Dcfg File Not Exist");
                            return false;
                        }

                        dict_Ref_saveDcfg.Clear();
                        status = ExecuteSaveConfig(savedDcfg);
                    }
                    else
                    {
                        MessageBox.Show("Wrong File Format. Expected .dcfg format");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception in Parse_SavedDcfg API = " + ex);
            }

            return status;
        }

        private bool ExecuteSaveConfig(string cfgpath)
        {
            try
            {
                using (var configFileReader = new StreamReader(cfgpath))
                {
                    if (configFileReader == null)
                    {
                        MessageBox.Show("Cannot open saved dcfg file to reformat");
                        return false;
                    }

                    string line;
                    string[] words;

                    while ((line = configFileReader.ReadLine()) != null)
                    {
                        line = line.Replace('\t', ' ');
                        line = line.Trim();
                        if (line.Length == 0)
                            continue;

                        var pos = line.IndexOf('#');
                        if (pos != -1)
                            line = line.Substring(0, pos);

                        line = line.Trim();

                        line = Regex.Replace(line, @"\s+", " ");    //To replace the 'n' spaces to a single space
                        words = line.Split(' ');

                        if (!line.Contains("_"))
                        {
                            AddRegPairList(words);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }

            return true;
        }

        public void AddRegPairList(string[] words)
        {
            uint regAddress;
            uint regValue;

            try
            {
                if (words.Count() >= 2)
                {
                    if (isHex(words[1]))
                    {
                        regAddress = (uint)Convert.ToUInt64(words[0], 16);
                        regValue = (uint)Convert.ToUInt64(words[1], 16);
                        dict_Ref_saveDcfg.Add(regAddress, regValue);
                        Console.WriteLine(regAddress.ToString("X2") + "  " + regValue.ToString("X4"));
                    }
                    else
                    {
                        Console.WriteLine("Error in values... skipping");
                    }
                }
                else
                {
                    Console.WriteLine("Error in values... skipping");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception in AddRegPairList API = " + ex);
            }
        }

        private bool isHex(string value)
        {
            if (value.StartsWith("0x"))
                value = value.Substring(2);
            return value.All(c => "0123456789abcdefABCDEF\n".Contains(c));
        }

        private void PopulateRegisterInfoList()
        {
            uint reg_def_addr = 0;
            try
            {
                foreach (var item in dict_Ref_saveDcfg)
                {
                    var dcfg_Reg_Address = item.Key;
                    var dcfg_Reg_Value = item.Value;
                    var reg_def = m_rc.FindRegisterDefinition_ByAddress(dcfg_Reg_Address);
                    var r_address = StringToByteArray(reg_def.r_address);
                    if (r_address.Length > 1)
                    {
                        reg_def_addr = (uint)(((r_address[1] << 0) & 0x00FF) | ((r_address[0] << 8) & 0xFF00));
                    }
                    else
                    {
                        reg_def_addr = r_address[0];
                    }
                    var regInfo_inst = new RegisterInfo()
                    {
                        reg_Address = reg_def_addr,
                        reg_Name = reg_def.r_name,
                        reg_Value = dcfg_Reg_Value,
                        reg_Description = reg_def.r_description,
                        reg_Category = reg_def.r_category,
                        reg_display = reg_def.r_display,
                    };

                    dict_RegisterInfo_All.Add(dcfg_Reg_Address, regInfo_inst);
                    sorted_dict_RegisterInfo_All.Add(dcfg_Reg_Address, regInfo_inst);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception in PopulateRegisterInfoList API = " + ex);
            }
        }


        public byte[] StringToByteArray(String hex)
        {
            int NumberChars = hex.Length;
            byte[] bytes = new byte[NumberChars / 2];
            for (int i = 0; i < NumberChars; i += 2)
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
            return bytes;
        }

        private bool Categorize_RegisterInfo(string savedDcfgPath)
        {
            string category = string.Empty;
            try
            {
                if (!File.Exists(savedDcfgPath))
                {
                    return false;
                }

                using (var saveDcfgWriter = new StreamWriter(savedDcfgPath))
                {
                    if (saveDcfgWriter == null)
                    {
                        return false;
                    }

                    foreach (var item in dict_RegisterInfo_All)
                    {
                        category = item.Value.reg_Category;
                        if (dict_RegisterInfo_categorized.ContainsKey(category) == false)
                        {
                            dict_RegisterInfo_categorized[category] = new SortedDictionary<uint, RegisterInfo>();
                        }

                        dict_RegisterInfo_categorized[category].Add(item.Key, item.Value);
                    }

                    foreach (var item in dict_RegisterInfo_categorized)
                    {
                        category = item.Key;
                        if (lst_TimeSlotX_category.Contains(category))
                        {
                            foreach (var val in item.Value)
                            {
                                var reg_name = val.Value.reg_Name;
                                var CategoryName_slotX = "TimeSlot Configuration - " + reg_name.Substring(reg_name.Length - 1);

                                if (dict_TimeSlotX_categorized.ContainsKey(CategoryName_slotX) == false)
                                {
                                    dict_TimeSlotX_categorized[CategoryName_slotX] = new SortedDictionary<uint, RegisterInfo>();
                                }

                                dict_TimeSlotX_categorized[CategoryName_slotX].Add(val.Key, val.Value);
                            }
                        }
                        else
                        {
                            WriteToFile(saveDcfgWriter, item.Key, item.Value);
                        }
                    }

                    foreach (var item in dict_TimeSlotX_categorized)
                    {
                        WriteToFile(saveDcfgWriter, item.Key, item.Value);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception in Categorize_RegisterInfo API = " + ex);
            }
            return true;
        }

        private void WriteToFile(StreamWriter fileWriter, string Category, SortedDictionary<uint, RegisterInfo> dict_RegisterInfo)
        {
            string reg_Name = string.Empty;
            uint reg_address = 0;
            uint reg_value = 0;
            string reg_Description = string.Empty;
            string str_format = string.Empty;
            bool reg_Display = true;

            try
            {
                if (!Category.Contains("None"))
                {
                    foreach (var registerInfo in dict_RegisterInfo)
                    {
                        if (registerInfo.Value.reg_display)
                        {
                            fileWriter.WriteLine("##  " + Category);
                            Console.WriteLine("##  " + Category);
                            break;
                        }
                    }
                }

                foreach (var val in dict_RegisterInfo)
                {
                    reg_Name = val.Value.reg_Name;
                    reg_address = val.Value.reg_Address;
                    reg_value = val.Value.reg_Value;
                    reg_Description = val.Value.reg_Description;
                    reg_Display = val.Value.reg_display;
                    str_format = reg_address.ToString("X2") + "  " + reg_value.ToString("X4") + "  # " + reg_Name;

                    if (reg_Description != XML_EMPTY_STRING)
                    {
                        str_format += "  -  " + reg_Description;
                    }

                    if (reg_Display)
                    {
                        fileWriter.WriteLine(str_format);
                        Console.WriteLine(str_format);
                    }
                }

                if (!Category.Contains("None"))
                {
                    foreach (var registerInfo in dict_RegisterInfo)
                    {
                        if (registerInfo.Value.reg_display)
                        {
                            fileWriter.WriteLine("");
                            Console.WriteLine("");
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in WriteToFile API = " + ex);
            }
        }

        private void CreateDcfgHeaderFile(string savedDcfgPath)
        {
            try
            {
                var cfg_filename = Path.GetDirectoryName(savedDcfgPath) + "\\" + Path.GetFileNameWithoutExtension(savedDcfgPath) + ".h";

                string sHFileName;
                string datContent;

                sHFileName = cfg_filename;

                datContent = "#define ADI_DCFG_H \n";
                datContent += "#define DCFG_ENTRIES " + sorted_dict_RegisterInfo_All.Count + "\n\n";

                datContent += "typedef struct { \n";
                datContent += "\tuint16_t addr; \n";
                datContent += "\tuint16_t value; \n";
                datContent += "} ADI_DCFG_t; \n\n";

                datContent += "ADI_DCFG_t dcfg[DCFG_ENTRIES] = \n";
                datContent += "{ \n";

                #region AWT Header

                var last = sorted_dict_RegisterInfo_All.Last();
                foreach (var item in sorted_dict_RegisterInfo_All)
                {
                    if (item.Equals(last))
                    {
                        datContent += "\t{0x" + item.Value.reg_Address.ToString("X3") + ", 0x" + item.Value.reg_Value.ToString("X4") + "}\n";
                    }
                    else
                    {
                        datContent += "\t{0x" + item.Value.reg_Address.ToString("X3") + ", 0x" + item.Value.reg_Value.ToString("X4") + "},\n";
                    }
                }

                datContent += "}; \n";

                #endregion
                System.IO.File.WriteAllText(sHFileName, datContent);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exeption in CreateDcfgHeaderFile API = " + ex);
            }
        }

        #endregion
    }

    public class RegisterInfo
    {
        public string reg_Name { get; set; }
        public uint reg_Address { get; set; }
        public uint reg_Value { get; set; }
        public string reg_Description { get; set; }
        public string reg_Category { get; set; }
        public bool reg_display { get; set; }
        public bool reg_IsReadOnly { get; set; }

        public RegisterInfo()
        {
            reg_Name = "None";
            reg_Address = 0;
            reg_Value = 0;
            reg_Description = "None";
            reg_Category = "None";
            reg_display = false;
            reg_IsReadOnly = true;
        }
    }

}
