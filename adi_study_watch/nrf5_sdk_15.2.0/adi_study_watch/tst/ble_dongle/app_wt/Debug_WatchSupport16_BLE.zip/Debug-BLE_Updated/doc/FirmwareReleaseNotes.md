#3.6.4 Release Notes #
 - Added Sub-sampling support for ADPD4100.
 - Added interrupt status support for ADPD4000/ADPD4100.

#3.6.3 Release Notes #
 - On M3 higher sampling rate time-stamp issue fixed.
 - Ticks for previous and current day time crossing handled in logging.

#3.6.2 Release Notes #
 - Negative time zone supported for M3 platform.
 - Adpd4000 will support all the sample types.

#3.6.1 Release Notes #
- Adpd400x PPG support added.
- Shutdown command added for M3 platform.

#3.6.0 Release Notes #
- Timestamp tick modified for M3 platform
- Clock calibration modified for ADPD4000 1MHz LFOSC

#3.5.9 Release Notes #
- PPG support added for ADPD1081 device.

#3.5.8 Release Notes #
- Battery charger initialization sequence changed
- DUT power disabled while doing the hardware initialization.

#3.5.7 Release Notes #
- Sensor Softreset method added in Opendriver
- Channel 2 data skipping issue fixed

# 3.5.6 Release Notes #
- ADPD4000/1 3-byte data format issue�fix
- Boost and no EEPROM case added

# 3.5.5 Release Notes #
- FreeRTOS kernel support added in the firmware

# 3.5.4 Release Notes #
- Fifo watermark level setting changed based on enabled slot's in adpdCl_drv files
- Memory optimization done for stream sub/unsub in coolidge sensor
- Adxl load configuration argument modified

# 3.5.3 Release Notes #
- Packet NULL pointer checking added
- UART BSP file updated for M4 platform to avoid hang-up in long hour testing

# 3.5.2 Release Notes #
- Efuse read command added in adpd_task
- Multi slot packet sequence number added

# 3.5.0 Release Notes #
- Packet Sequence number updated for Slot A & B

# 3.4.5 Release Notes #
- AD5110 Read and Write feature added
- EEPROM Read and Write feature added
- Sand Box feature added

# 3.4.2 Release Notes #
- Default load configuration file changed for rev9 & revA chip
- Ken float mode changes added
- Adxl support added for M4 platform

# 3.4.1 Release Notes #

## Firmware Updates ##

- Application Wavetool version 2.0.0 supports this firmware.


# 3.4.0 Release Notes #


**IMPORTANT:** Before updating, it is recommended to retrieve all logs taken with your current release, this will prevent loss of logs due to automatic NAND Flash formatting with 3.4.0.

## Firmware Updates ##

**M2M2**

- Power Boost command added for M4 platform

## Tools ##

**General**
- Bluetooth Support added for M4 platform

**VSM WaveTool**

- JSON updates to include pedometer timestamp and user defined key-value pair.
- Update of firmware now works with Windows 10.
- Cloud upload support with metadata.
- New logging interface.
- 125% display support.
- UI enhanced with Metroframework.
- Subject ID from logging automatically used as participant ID on cloud upload.

