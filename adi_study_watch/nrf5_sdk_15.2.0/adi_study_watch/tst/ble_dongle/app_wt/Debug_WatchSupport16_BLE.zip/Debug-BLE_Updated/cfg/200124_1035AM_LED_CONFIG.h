#define ADI_DCFG_H 
#define DCFG_ENTRIES 6

typedef struct { 
	uint16_t addr; 
	uint16_t value; 
} ADI_DCFG_t; 

ADI_DCFG_t dcfg[DCFG_ENTRIES] = 
{ 
	{0x000, 0x0000},
	{0x001, 0x000F},
	{0x105, 0x0005},
	{0x125, 0x0900},
	{0x146, 0x0003},
	{0x166, 0x1100}
}; 
