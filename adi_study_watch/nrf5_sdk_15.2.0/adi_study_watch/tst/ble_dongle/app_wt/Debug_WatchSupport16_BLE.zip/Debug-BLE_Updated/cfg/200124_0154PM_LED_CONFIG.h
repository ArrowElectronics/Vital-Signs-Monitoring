#define ADI_DCFG_H 
#define DCFG_ENTRIES 4

typedef struct { 
	uint16_t addr; 
	uint16_t value; 
} ADI_DCFG_t; 

ADI_DCFG_t dcfg[DCFG_ENTRIES] = 
{ 
	{0x105, 0x007F},
	{0x125, 0x5500},
	{0x146, 0x007F},
	{0x166, 0x3700}
}; 
